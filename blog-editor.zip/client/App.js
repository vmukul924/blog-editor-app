import { useState, useEffect, useCallback } from 'react'
import axios from 'axios'
import debounce from 'lodash.debounce'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'

function App() {
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [tags, setTags] = useState('')
  const [blogId, setBlogId] = useState(null)
  const [blogs, setBlogs] = useState([])

  const fetchBlogs = async () => {
    const res = await axios.get('http://localhost:5000/api/blogs')
    setBlogs(res.data)
  }

  useEffect(() => {
    fetchBlogs()
  }, [])

  const saveDraft = async () => {
    const res = await axios.post('http://localhost:5000/api/blogs/save-draft', {
      id: blogId,
      title,
      content,
      tags: tags.split(',').map(t => t.trim())
    })
    if (!blogId) setBlogId(res.data._id)
    toast.success('Draft saved')
    fetchBlogs()
  }

  const publish = async () => {
    const res = await axios.post('http://localhost:5000/api/blogs/publish', {
      id: blogId,
      title,
      content,
      tags: tags.split(',').map(t => t.trim())
    })
    toast.success('Published')
    fetchBlogs()
  }

  const debouncedSave = useCallback(debounce(saveDraft, 5000), [title, content, tags])

  useEffect(() => {
    if (title || content) debouncedSave()
  }, [title, content, tags, debouncedSave])

  return (
    <div>
      <h2>Blog Editor</h2>
      <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Title" />
      <textarea value={content} onChange={e => setContent(e.target.value)} placeholder="Content" />
      <input value={tags} onChange={e => setTags(e.target.value)} placeholder="Tags (comma-separated)" />
      <button onClick={saveDraft}>Save Draft</button>
      <button onClick={publish}>Publish</button>
      <h3>Published Blogs</h3>
      <ul>{blogs.filter(b => b.status === 'published').map(b => <li key={b._id}>{b.title}</li>)}</ul>
      <h3>Drafts</h3>
      <ul>{blogs.filter(b => b.status === 'draft').map(b => <li key={b._id}>{b.title}</li>)}</ul>
      <ToastContainer position="bottom-right" />
    </div>
  )
}

export default App