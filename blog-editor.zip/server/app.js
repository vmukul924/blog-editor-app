const express = require('express')
const mongoose = require('mongoose')
const cors = require('cors')
require('dotenv').config()
const app = express()
app.use(cors())
app.use(express.json())
const Blog = require('./models/Blog')

app.post('/api/blogs/save-draft', async (req, res) => {
  const { id, title, content, tags } = req.body
  const data = { title, content, tags, status: 'draft', updated_at: new Date() }
  try {
    let blog
    if (id) {
      blog = await Blog.findByIdAndUpdate(id, data, { new: true })
    } else {
      data.created_at = new Date()
      blog = await Blog.create(data)
    }
    res.json(blog)
  } catch (e) {
    res.status(500).json({ error: 'Error saving draft' })
  }
})

app.post('/api/blogs/publish', async (req, res) => {
  const { id, title, content, tags } = req.body
  const data = { title, content, tags, status: 'published', updated_at: new Date() }
  try {
    let blog
    if (id) {
      blog = await Blog.findByIdAndUpdate(id, data, { new: true })
    } else {
      data.created_at = new Date()
      blog = await Blog.create(data)
    }
    res.json(blog)
  } catch (e) {
    res.status(500).json({ error: 'Error publishing blog' })
  }
})

app.get('/api/blogs', async (req, res) => {
  try {
    const blogs = await Blog.find().sort({ updated_at: -1 })
    res.json(blogs)
  } catch (e) {
    res.status(500).json({ error: 'Error fetching blogs' })
  }
})

app.get('/api/blogs/:id', async (req, res) => {
  try {
    const blog = await Blog.findById(req.params.id)
    res.json(blog)
  } catch (e) {
    res.status(500).json({ error: 'Error fetching blog' })
  }
})

mongoose.connect(process.env.MONGO_URI).then(() => {
  app.listen(process.env.PORT, () => console.log(`Server running`))
})
